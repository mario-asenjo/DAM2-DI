"""
CAPA DE VISTA: VIEWERS QUE COMUNICAN CON ADAPTER
"""

from .carta_view import CartaView
from .tablero_view import TableroView

__all__ = ["CartaView", "TableroView"]