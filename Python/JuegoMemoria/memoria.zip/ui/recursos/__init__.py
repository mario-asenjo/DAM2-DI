"""
CAPA RECURSOS: para proveer a cada carta su imagen correspondiente
"""

from .image_provider import ImageProvider

__all__ = ["ImageProvider"]